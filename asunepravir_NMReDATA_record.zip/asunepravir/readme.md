Asunaprevir is an experimental drug candidate for the treatment of hepatitis C. The file contains 13c and 1h 1D spectra. There are COSY, TOCSY, HSQC-EDITED, HMBC, and NOESY 2d spectra. There are two 1H spectra, the second one has #2 appended. There is a NMREDATA_J section for coupling constants.  

Reference: J Nat Prod 2017, 80, 2060–2066